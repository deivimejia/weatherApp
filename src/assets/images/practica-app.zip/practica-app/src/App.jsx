/**
 * Practica
 * Traer todos los paises que hablen un idioma en especifico
 * @see https://restcountries.com
 * path: /lang/{idioma}
 */

function App () {
  /**
   * Puedes instalar axios para hacer peticiones
   * Crea todos los estados, efectos y funciones necesarias
   * Crea un componente CountryList que reciba un arreglo de paises
   * Crea un componente Country que reciba un pais con los siguientes datos:
   * - Nombre
   * - Bandera
   * - Limites (Solo el nombre) con otros paises
   * Deberas listar los paises que limiten con el pais seleccionado
   */
  return (
    <div>
      <h1>Practica App</h1>
    </div>
  )
}

export default App
